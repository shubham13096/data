import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pptx import Presentation
from pptx.util import Inches

# Set seaborn style
sns.set(style="whitegrid")

# Load dataset
file_path = "C:/Users/ASUS/Downloads/Unemployment in India.csv"
df = pd.read_csv(file_path)

# Clean column names
df.columns = df.columns.str.strip()

# Convert 'Date' to datetime format
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)

# Drop missing values
df.dropna(inplace=True)

# Create PowerPoint presentation
prs = Presentation()

# Function to add a slide with image and title
def add_slide_with_image(prs, title, image_path):
    slide_layout = prs.slide_layouts[5]  # Blank layout
    slide = prs.slides.add_slide(slide_layout)
    
    # Add title box
    title_shape = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(9), Inches(1))
    title_frame = title_shape.text_frame
    title_frame.text = title

    # Add image
    slide.shapes.add_picture(image_path, Inches(1), Inches(1.2), width=Inches(8))


# Plot 1: Unemployment Rate Over Time
monthly_trend = df.groupby("Date")["Estimated Unemployment Rate (%)"].mean()
plt.figure(figsize=(12, 6))
monthly_trend.plot(marker='o')
plt.title("Average Unemployment Rate Over Time (India)")
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")
plt.grid(True)
plt.tight_layout()
plt.savefig("plot1_trend.png")
plt.close()
add_slide_with_image(prs, "Unemployment Rate Over Time", "plot1_trend.png")

# Plot 2: Pre-Covid vs During Covid
df["Covid Era"] = df["Date"].apply(lambda x: "Pre-Covid" if x < pd.to_datetime("2020-03-01") else "During Covid")
plt.figure(figsize=(8, 5))
sns.boxplot(x="Covid Era", y="Estimated Unemployment Rate (%)", data=df)
plt.title("Unemployment Rate: Pre-Covid vs During Covid")
plt.tight_layout()
plt.savefig("plot2_covid.png")
plt.close()
add_slide_with_image(prs, "Pre-Covid vs During-Covid", "plot2_covid.png")

# Plot 3: State-wise Average Unemployment
state_avg = df.groupby("Region")["Estimated Unemployment Rate (%)"].mean().sort_values(ascending=False)
plt.figure(figsize=(10, 12))
state_avg.plot(kind='barh', color='teal')
plt.xlabel("Average Unemployment Rate (%)")
plt.title("State-wise Average Unemployment Rate")
plt.gca().invert_yaxis()
plt.tight_layout()
plt.savefig("plot3_state.png")
plt.close()
add_slide_with_image(prs, "State-wise Unemployment Rate", "plot3_state.png")

# Plot 4: Urban vs Rural Unemployment
plt.figure(figsize=(8, 5))
sns.boxplot(x="Area", y="Estimated Unemployment Rate (%)", data=df)
plt.title("Urban vs Rural Unemployment Rate")
plt.tight_layout()
plt.savefig("plot4_area.png")
plt.close()
add_slide_with_image(prs, "Urban vs Rural Unemployment", "plot4_area.png")

# Plot 5: Correlation Heatmap
numeric = df.select_dtypes(include='float64')
plt.figure(figsize=(8, 6))
sns.heatmap(numeric.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("plot5_corr.png")
plt.close()
add_slide_with_image(prs, "Correlation Heatmap", "plot5_corr.png")

# Save PowerPoint file
prs.save("Unemployment_Analysis_Presentation.pptx")
print("Presentation created: Unemployment_Analysis_Presentation.pptx")
